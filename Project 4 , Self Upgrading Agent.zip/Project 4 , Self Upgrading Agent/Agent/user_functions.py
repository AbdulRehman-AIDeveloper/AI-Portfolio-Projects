# user_functions.py

def is_even(n: int) -> bool:
    return n % 2 == 0

def calculate_profit(total_sales, total_costs):
    return total_sales - total_costs
