# brain/file_writer.py
def append_function_to_file(code_str, file_path="user_functions.py"):
    with open(file_path, "a", encoding="utf-8") as f:
        f.write("\n\n" + code_str.strip() + "\n")
