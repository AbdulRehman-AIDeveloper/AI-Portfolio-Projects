# brain/module_loader.py
import importlib.util

def load_functions_from_file(file_path="user_functions.py"):
    spec = importlib.util.spec_from_file_location("user_functions", file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
