# brain/code_generator.py
import requests
from config import OPENROUTER_API_KEY, MODEL

def generate_code_from_prompt(prompt):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "HTTP-Referer": "https://yourdomain.com",
        "X-Title": "Self-Upgrading-Agent"
    }

    data = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful coding assistant. Return only clean Python code with no markdown or explanation."},
            {"role": "user", "content": f"Write a single Python function for: {prompt}"}
        ]
    }

    response = requests.post("https://openrouter.ai/api/v1/chat/completions", json=data, headers=headers)
    raw = response.json()["choices"][0]["message"]["content"]

    # Clean markdown if any slipped through
    if "```" in raw:
        raw = raw.split("```")[1]
        if raw.startswith("python"):
            raw = raw[len("python"):]

    # Remove leading/trailing whitespace
    return raw.strip()
