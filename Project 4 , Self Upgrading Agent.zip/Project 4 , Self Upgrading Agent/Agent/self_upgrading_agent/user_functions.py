# user_functions.py

def is_even(n: int) -> bool:
    return n % 2 == 0

def calculate_profit(total_sales, total_costs):
    profit = total_sales - total_costs
    return profit


def add_numbers(a, b):
    return a + b


def multiply(a, b):
    return a * b


def multiply(a, b):
    return a * b


def multiply(a, b):
    return a * b


def divide(dividend, divisor):
    return dividend / divisor


def divide(a, b):
    return a / b

result = divide(9, 3)
print(result)


def calculate_profit(total_income, total_cost):
    profit = total_income - total_cost
    return profit


def calculate_profit(cost, selling_price):
    profit = selling_price - cost
    return profit


def factorial(n):
    return 1 if n == 0 else n * factorial(n-1)

print(factorial(7))


def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n-1)
