# config.py
OPENROUTER_API_KEY = "sk-or-v1-......"
MODEL = "mistralai/mistral-7b-instruct"
