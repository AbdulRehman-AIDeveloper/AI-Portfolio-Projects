def append_function_to_file(filepath, function_code):
    with open(filepath, "a", encoding="utf-8") as f:
        f.write("\n\n" + function_code.strip() + "\n") 