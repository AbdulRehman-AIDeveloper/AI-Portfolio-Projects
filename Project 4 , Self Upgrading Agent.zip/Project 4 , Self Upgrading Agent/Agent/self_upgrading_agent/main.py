# self_upgrading_agent/main.py
import importlib
import sys
import os
import json
import traceback
from brain.code_generator import generate_code_from_prompt
from utils.file_manager import append_function_to_file
from brain.module_loader import load_functions_from_file

sys.path.append(os.path.dirname(__file__))

USER_FUNCTIONS_PATH = "self_upgrading_agent/user_functions.py"
MEMORY_FILE = "memory.json"

print(">>> Self-Upgrading Terminal Agent Activated (Mistral via OpenRouter)\n")

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    return {"functions": []}

def save_memory(memory):
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f, indent=2)

def main():
    memory = load_memory()

    while True:
        command = input("Enter a command ('exit' to quit, 'call [func] args...' to run): ").strip()

        if command == "exit":
            break

        if command.startswith("call "):
            try:
                parts = command.split()
                func_name = parts[1]
                args = parts[2:]

                # Dynamically load user_functions.py
                spec = importlib.util.spec_from_file_location("user_functions", USER_FUNCTIONS_PATH)
                user_funcs = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(user_funcs)

                # Get function and call with arguments
                func = getattr(user_funcs, func_name)
                result = func(*[eval(arg) for arg in args])
                print("→ Result:", result)

            except Exception as e:
                print("⚠️ Error:", e)
                traceback.print_exc()
            continue

        # If not a 'call' command, treat as function generation
        print("\n🧠 Generating Python code using Mistral...")
        code = generate_code_from_prompt(command)

        print("📦 Generated Code:\n", code)
        try:
            append_function_to_file(USER_FUNCTIONS_PATH, code)
            print("✅ Function added. You can now call it.")
            memory["functions"].append(command)
            save_memory(memory)
        except Exception as e:
            print("❌ Failed to save function:", e)

if __name__ == "__main__":
    main()
