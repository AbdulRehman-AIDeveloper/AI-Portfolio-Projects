import requests
import json
import os
import datetime
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# ---------- CONFIGURATION ----------
OPENROUTER_API_KEY = "sk-or-v1......"
BLOG_ID = "6559320639074561411"  # Get this from your Blogger dashboard
CREDENTIALS_FILE = "credentials.json"  # Download this from Google Cloud Console
SCOPES = ['https://www.googleapis.com/auth/blogger']
# ----------------------------------

# Authenticate with Google Blogger API
def get_blogger_service():
    creds = None
    token_file = "token.json"

    if os.path.exists(token_file):
        creds = Credentials.from_authorized_user_file(token_file, SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(token_file, 'w') as token:
            token.write(creds.to_json())

    return creds

# Generate blog using OpenRouter API + Mistral
def generate_blog(topic):
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
    }
    data = {
        "model": "mistralai/mistral-7b-instruct",
        "messages": [
            {"role": "system", "content": "You are a professional blog writer."},
            {"role": "user", "content": f"Write a high-quality, SEO-optimized blog post on the topic: '{topic}'."}
        ]
    }
    response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)
    response.raise_for_status()
    content = response.json()['choices'][0]['message']['content']
    return content

# Post to Blogspot
def post_to_blogspot(title, content, creds):
    url = f"https://www.googleapis.com/blogger/v3/blogs/{BLOG_ID}/posts/"
    headers = {
        'Authorization': f'Bearer {creds.token}',
        'Content-Type': 'application/json'
    }
    post_data = {
        "kind": "blogger#post",
        "title": title,
        "content": content
    }
    response = requests.post(url, headers=headers, data=json.dumps(post_data))
    response.raise_for_status()
    print("✅ Blog posted successfully!")
    print("🔗 URL:", response.json().get("url"))

# Main agent function
def run_agent():
    topic = input("Enter a topic for the blog: ").strip()
    print("🧠 Generating blog post with Mistral...")
    blog_content = generate_blog(topic)
    title = f"{topic.title()} - {datetime.datetime.now().strftime('%B %d, %Y')}"
    print("📝 Posting to Blogspot...")
    creds = get_blogger_service()
    post_to_blogspot(title, blog_content, creds)

if __name__ == "__main__":
    run_agent()
