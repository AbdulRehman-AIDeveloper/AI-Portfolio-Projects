import requests

# Replace with your OpenRouter API key
API_KEY = "sk-or-v......."
MODEL = "mistralai/mistral-7b-instruct"  # You can change to google/gemini-pro if needed

# Build the prompt for rewriting
def build_rewriting_prompt(user_prompt):
    return f"""
You are an expert AI prompt engineer.

Your task is to rewrite the following user prompt to be:
- More specific
- More effective
- Structured
- Easy for AI models to understand and execute

Only output the rewritten prompt. Avoid explanation.

Original prompt:
\"\"\"{user_prompt}\"\"\"
"""

# Send to OpenRouter
def rewrite_prompt(user_prompt):
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful and creative AI prompt rewriter."},
            {"role": "user", "content": build_rewriting_prompt(user_prompt)}
        ]
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 200:
        return response.json()["choices"][0]["message"]["content"]
    else:
        return f"❌ API Error: {response.status_code} - {response.text}"

# 🔁 Main function
def run_prompt_rewriter():
    print("🎯 AI Prompt Rewriter — Make Any Prompt 10x Better\n")
    user_prompt = input("Enter your basic prompt: ")

    print("\n⏳ Rewriting with AI...")
    improved_prompt = rewrite_prompt(user_prompt)

    print("\n🧠 Rewritten Prompt:\n")
    print(improved_prompt)

if __name__ == "__main__":
    run_prompt_rewriter()
