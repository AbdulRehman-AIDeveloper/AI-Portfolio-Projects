import os
import docx2txt
from pdfminer.high_level import extract_text
import requests

# 🔑 Replace with your actual OpenRouter API key
OPENROUTER_API_KEY = "sk-or-v1....."
MODEL = "mistralai/mistral-7b-instruct" # or "google/gemini-pro", etc.

# Extract text from PDF or DOCX
def extract_resume_text(path):
    if path.endswith(".pdf"):
        return extract_text(path)
    elif path.endswith(".docx"):
        return docx2txt.process(path)
    else:
        return ""

# Prepare AI prompt
def build_prompt(resume_text):
    return f"""
You are an expert resume analyst and HR advisor.

Analyze the following resume text and provide:
1. ATS compatibility score (0 to 100)
2. Key strengths
3. Missing elements (like formatting, skills, or structure)
4. Suggestions for improvement
5. Which type of jobs this resume is best suited for

Resume Text:
\"\"\"
{resume_text}
\"\"\"
Give your response in bullet points.
"""

# Send to OpenRouter
def analyze_resume_with_ai(text):
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful AI resume reviewer."},
            {"role": "user", "content": build_prompt(text)}
        ]
    }

    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        result = response.json()
        return result["choices"][0]["message"]["content"]
    else:
        return f"❌ API Error: {response.status_code} - {response.text}"

# Main logic
def run_resume_ai():
    print("📄 AI Resume Analyzer with LLM (OpenRouter)\n")
    path = input("Enter path to resume (.pdf or .docx): ")

    if not os.path.exists(path):
        print("❌ File not found.")
        return

    resume_text = extract_resume_text(path)
    print("✅ Resume extracted. Sending to AI for analysis...")

    result = analyze_resume_with_ai(resume_text)
    print("\n🔍 Resume Review Report:\n")
    print(result)

if __name__ == "__main__":
    run_resume_ai()
